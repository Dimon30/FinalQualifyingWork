
# quad_sim_py

Небольшой Python-порт динамики квадрокоптера из диссертации.

## Что внутри
- `model.py` — динамика (x,y,z,vx,vy,vz,phi,theta,psi,phidot,thetadot,psidot) и преобразование `u -> F1..F4`.
- `integrators.py` — симулятор на `scipy.integrate.solve_ivp` и простой RK4.
- `trajectories.py` — примеры траекторий (линия и спираль).
- `controllers.py` — простой PD-трекинг (как заглушка) + ограничение u1.
- `run_demo.py` — демо-симуляция и графики.

## Установка
```bash
pip install numpy scipy matplotlib
```

## Запуск
```bash
python run_demo.py
```
