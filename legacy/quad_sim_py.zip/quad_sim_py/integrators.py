from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Tuple

import numpy as np

try:
    from scipy.integrate import solve_ivp
except Exception:  # pragma: no cover
    solve_ivp = None

from model import QuadParams, quad_ode


@dataclass(frozen=True)
class SimResult:
    t: np.ndarray          # shape (N,)
    x: np.ndarray          # shape (N, 12)


def rk4_step(f: Callable[[float, np.ndarray], np.ndarray], t: float, x: np.ndarray, dt: float) -> np.ndarray:
    k1 = f(t, x)
    k2 = f(t + dt/2.0, x + dt*k1/2.0)
    k3 = f(t + dt/2.0, x + dt*k2/2.0)
    k4 = f(t + dt, x + dt*k3)
    return x + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)


def simulate_rk4(
    t0: float,
    tf: float,
    dt: float,
    x0: np.ndarray,
    u_fun: Callable[[float, np.ndarray], Tuple[float, float, float, float]],
    params: QuadParams = QuadParams(),
    u1_limit_l: float = 0.9,
) -> SimResult:
    f = lambda t, x: quad_ode(t, x, u_fun=u_fun, p=params, u1_limit_l=u1_limit_l)
    t = np.arange(t0, tf + 1e-12, dt)
    xs = np.zeros((len(t), len(x0)), dtype=float)
    xs[0] = x0
    for i in range(1, len(t)):
        xs[i] = rk4_step(f, t[i-1], xs[i-1], dt)
    return SimResult(t=t, x=xs)


def simulate_solve_ivp(
    t_span: Tuple[float, float],
    t_eval: np.ndarray,
    x0: np.ndarray,
    u_fun: Callable[[float, np.ndarray], Tuple[float, float, float, float]],
    params: QuadParams = QuadParams(),
    u1_limit_l: float = 0.9,
    rtol: float = 1e-7,
    atol: float = 1e-9,
) -> SimResult:
    if solve_ivp is None:
        raise RuntimeError("scipy не установлен, используйте simulate_rk4().")

    fun = lambda t, x: quad_ode(t, x, u_fun=u_fun, p=params, u1_limit_l=u1_limit_l)
    sol = solve_ivp(fun, t_span=t_span, y0=x0, t_eval=t_eval, rtol=rtol, atol=atol, method="RK45")
    if not sol.success:
        raise RuntimeError(f"solve_ivp failed: {sol.message}")
    return SimResult(t=sol.t, x=sol.y.T)
