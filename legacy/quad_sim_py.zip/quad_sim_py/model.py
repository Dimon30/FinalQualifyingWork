"""Динамика квадрокоптера и вспомогательные преобразования.

Базовая модель движения в пространстве (без трения) приведена в диссертации
в виде (52)–(54):

    p_dot = v
    v_dot = b(phi, theta, psi) * (u1 + g) - [0,0,g]
    phi_ddot   = u2
    theta_ddot = u3
    psi_ddot   = u4

где b(phi,theta,psi) — вектор направления тяги в стационарной системе координат,
записанный в явном виде через углы Эйлера.

Дополнительно:
- sat_smooth() — гладкая «насыщающая» функция (нужна, т.к. в диссертации u1
  ограничивается: -l*g <= u1 <= l*g).
- u_to_rotor_forces() — перевод (u1,u2,u3,u4) в тяги роторов (F1..F4) по формуле
  из диссертации (матрица 1/4 * A * B).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Tuple

import numpy as np


@dataclass(frozen=True)
class QuadParams:
    g: float = 9.81
    m: float = 1.0           # масса (кг)
    l: float = 0.25          # плечо (м) — расстояние от центра масс до ротора
    J_phi: float = 0.02      # момент инерции вокруг оси крена
    J_theta: float = 0.02    # момент инерции вокруг оси тангажа
    J_psi: float = 0.04      # момент инерции вокруг оси рысканья
    C_tau: float = 1.0       # коэффициент передачи крутящего момента


def sat_smooth(x: np.ndarray | float, level: float, k: float = 10.0) -> np.ndarray | float:
    """Гладкая сатурация: |sat(x)| < level, непрерывная и дифференцируемая."""
    return level * np.tanh(k * np.asarray(x) / level)


def thrust_direction(phi: float, theta: float, psi: float) -> np.ndarray:
    """b(phi,theta,psi) из (53): направление тяги в стационарной СК."""
    cphi, sphi = np.cos(phi), np.sin(phi)
    cth, sth = np.cos(theta), np.sin(theta)
    cps, sps = np.cos(psi), np.sin(psi)
    return np.array([
        cphi * sth * cps + sphi * sps,
        sphi * sth * cps - cphi * sps,
        cth * cps
    ], dtype=float)


def quad_ode(
    t: float,
    x: np.ndarray,
    u_fun: Callable[[float, np.ndarray], Tuple[float, float, float, float]],
    p: QuadParams = QuadParams(),
    u1_limit_l: float = 0.9,
    sat_k: float = 10.0,
) -> np.ndarray:
    """Правая часть ОДУ.

    Состояние x (12):
      [0:3]   p = (x,y,z)
      [3:6]   v = (vx,vy,vz)
      [6:9]   angles = (phi,theta,psi)
      [9:12]  ang_rates = (phidot,thetadot,psidot)

    Управление u = (u1,u2,u3,u4):
      u1 — "вертикальное" управление, в модели входит как (u1+g);
      u2,u3,u4 — угловые ускорения.

    Ограничение u1: -l*g <= u1 <= l*g (см. диссертацию), реализовано гладко.
    """
    vel = x[3:6]
    phi, theta, psi = x[6:9]
    phidot, thetadot, psidot = x[9:12]

    u1, u2, u3, u4 = u_fun(t, x)

    level = float(u1_limit_l) * p.g
    u1 = float(sat_smooth(u1, level=level, k=sat_k))

    b = thrust_direction(phi, theta, psi)
    acc = b * (u1 + p.g) - np.array([0.0, 0.0, p.g], dtype=float)

    xdot = np.zeros_like(x, dtype=float)
    xdot[0:3] = vel
    xdot[3:6] = acc
    xdot[6:9] = np.array([phidot, thetadot, psidot], dtype=float)
    xdot[9:12] = np.array([u2, u3, u4], dtype=float)
    return xdot


def u_to_rotor_forces(u1: float, u2: float, u3: float, u4: float, p: QuadParams = QuadParams()) -> np.ndarray:
    """Перевод (u1,u2,u3,u4) -> (F1..F4) по матричной формуле из диссертации."""
    A = np.array([
        [1,  1, -1, -1],
        [1, -1,  1, -1],
        [1,  1,  1,  1],
        [1, -1, -1,  1],
    ], dtype=float)

    B = np.diag([
        p.m,
        p.J_phi / p.C_tau,
        p.J_psi / p.l,
        p.J_theta / p.l,
    ], dtype=float)

    vec = np.array([u1 + p.g, u2, u3, u4], dtype=float)
    return 0.25 * (A @ (B @ vec))
