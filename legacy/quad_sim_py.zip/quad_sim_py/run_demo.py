import numpy as np
import matplotlib.pyplot as plt

from controllers import simple_pd_controller, PDGains
from integrators import simulate_solve_ivp, simulate_rk4
from trajectories import spiral_time_traj, line_s_traj


def main():
    tf = 15.0
    dt = 0.01
    t = np.arange(0.0, tf + 1e-12, dt)

    traj = spiral_time_traj(r=0.5)  # пример из диссертации (гл.3)
    u_fun = simple_pd_controller(traj, gains=PDGains(kp_pos=8, kd_pos=5, kp_ang=14, kd_ang=8), yaw_ref=0.0)

    # начальное состояние: [x,y,z, vx,vy,vz, phi,theta,psi, phidot,thetadot,psidot]
    x0 = np.zeros(12, dtype=float)
    x0[2] = 0.0  # z
    x0[6:9] = 0.0  # углы

    try:
        res = simulate_solve_ivp((0.0, tf), t, x0, u_fun=u_fun)
    except Exception:
        res = simulate_rk4(0.0, tf, dt, x0, u_fun=u_fun)

    pos = res.x[:, 0:3]
    vel = res.x[:, 3:6]
    ang = res.x[:, 6:9]

    ref = np.vstack([traj(tt).p for tt in res.t])

    # 3D траектория
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(ref[:,0], ref[:,1], ref[:,2], '--', linewidth=2, label='Заданная')
    ax.plot(pos[:,0], pos[:,1], pos[:,2], linewidth=2, label='Реальная')
    ax.set_xlabel('x, m')
    ax.set_ylabel('y, m')
    ax.set_zlabel('z, m')
    ax.legend()
    ax.grid(True)

    # Ошибка по координатам
    e = ref - pos
    plt.figure()
    plt.plot(res.t, e[:,0], label='x-x*')
    plt.plot(res.t, e[:,1], label='y-y*')
    plt.plot(res.t, e[:,2], label='z-z*')
    plt.plot(res.t, np.linalg.norm(e, axis=1), label='||e||')
    plt.xlabel('t, s')
    plt.ylabel('m')
    plt.legend()
    plt.grid(True)

    # Углы
    plt.figure()
    plt.plot(res.t, ang[:,0], label='phi')
    plt.plot(res.t, ang[:,1], label='theta')
    plt.plot(res.t, ang[:,2], label='psi')
    plt.xlabel('t, s')
    plt.ylabel('rad')
    plt.legend()
    plt.grid(True)

    plt.show()


if __name__ == '__main__':
    main()
