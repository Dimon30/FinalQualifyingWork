from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Tuple

from controllers.common import HighGainParams, DerivativeObserver4, sat_vec_tanh
from geometry import CurveGeom, nearest_point_line, spiral_nearest_observer_step, se_from_pose

@dataclass
class Ch4State:
    zeta: float = 0.0

class Ch4CoordinatedController:
    """Рабочая версия идеи главы 4: выход (s,e1,e2,δφ), цель s_dot->V*."""
    def __init__(self, curve: CurveGeom, Vstar: float, params: HighGainParams, use_spiral_observer: bool = False, r: float = 3.0):
        self.curve = curve
        self.Vstar = float(Vstar)
        self.p = params
        self.obs = DerivativeObserver4(dim=4, p=params)
        self.state = Ch4State()
        self.use_spiral_observer = use_spiral_observer
        self.r = r

    def _measure_outputs(self, x: np.ndarray, dt: float) -> Tuple[np.ndarray, float]:
        p = x[0:3]
        phi = float(x[6])
        if self.use_spiral_observer:
            self.state.zeta = spiral_nearest_observer_step(self.state.zeta, p, r=self.r, gamma=1.0, dt=dt)
            s = self.state.zeta
        else:
            s = nearest_point_line(p)

        s_loc, e1, e2 = se_from_pose(p, s, self.curve)
        phi_star = self.curve.yaw_star(s)
        dphi = np.arctan2(np.sin(phi - phi_star), np.cos(phi - phi_star))
        y = np.array([s_loc, e1, e2, dphi], dtype=float)
        return y, s

    def step(self, t: float, x: np.ndarray, Uprev: np.ndarray, dt: float) -> np.ndarray:
        y, s = self._measure_outputs(x, dt)

        # reference: s_dot -> V*, e1,e2,dphi -> 0
        y_ref  = np.array([y[0], 0.0, 0.0, 0.0], dtype=float)
        y1_ref = np.array([self.Vstar, 0.0, 0.0, 0.0], dtype=float)
        y2_ref = np.zeros(4)
        y3_ref = np.zeros(4)
        y4_ref = np.zeros(4)

        # используем high-gain как «дифференциатор» (для 1:1 надо подставить q,b как в главе 4)
        self.obs.step(y=y, y4_model=np.zeros(4), dt=dt)
        x1,x2,x3,x4,sigma = self.obs.hat()

        g1,g2,g3,g4,_ = self.p.gamma
        v = (y4_ref
             - sigma
             - g1*(x1 - y_ref)
             - g2*(x2 - y1_ref)
             - g3*(x3 - y2_ref)
             - g4*(x4 - y3_ref))

        return sat_vec_tanh(v, self.p.L)
